package com.example.a7510.herdproject.Common;


import com.example.a7510.herdproject.Model.User;

public class Common {
    public static User currentUser;
}
